from setuptools import setup

setup(name = "sptt",
      version = "0.1",
      description = "Spoken English To Written English Converter",
      author = "Navneet Kumar",
      setup_requires=['wheel'],
      packages = ["sptt"],
      install_requires = []
      )